package com.example.anupam.logix1;

/**
 * Created by Rajanish on 3/24/18.
 */

public interface AsyncSResponse {
    void processSFinish(String state);
}

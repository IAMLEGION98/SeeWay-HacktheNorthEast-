package com.example.anupam.logix1;

import android.app.Application;

public class GlobalVariables extends Application {

    public int wentin=0;
    public String role ="driver";

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public GlobalVariables()
    {

    }

    public int getWentin() {
        return wentin;
    }

    public void setWentin(int wentin) {
        this.wentin = wentin;
    }
}


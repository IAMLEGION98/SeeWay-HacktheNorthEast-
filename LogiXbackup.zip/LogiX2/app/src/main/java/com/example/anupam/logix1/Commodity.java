package com.example.anupam.logix1;

public class Commodity {

    String headerid;
    String sub;

    Commodity()
    {

    }

    public String getHeaderid() {
        return headerid;
    }

    public void setHeaderid(String headerid) {
        this.headerid = headerid;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }
}
